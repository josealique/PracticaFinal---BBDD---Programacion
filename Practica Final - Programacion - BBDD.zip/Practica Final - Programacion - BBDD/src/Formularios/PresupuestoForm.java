package Formularios;

import Clases.*;
import DAO.*;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.*;

public class PresupuestoForm {
    private JPanel MainPanel;
    private TableModel tableModel;
    private JComboBox<String> comboCli;
    private JComboBox<String> comboEmp;
    private JButton nuevoCli;
    private JButton nuevaEmp;
    private JTable productosTabla = new JTable();
    private JPanel panelTabla;
    private JButton insert;
    private JButton delete;
    private JButton update;
    private List<Cliente> clienteList = new ArrayList<>();
    private List<Empresa> empresaList = new ArrayList<>();
    private List<Presupuesto> presupuestos = new ArrayList<>();
    private List<List<Object>> list = new ArrayList<>();
    private final String[] columnas = new String[]{"Id Presupuesto", "Fecha de creacion", "DNI_Cliente", "Nombre Cliente", "DNI_Trabajador", "Nombre Trabajador", "Empresa", "Estado", "Productos", "Precio Total"};
    private final DAOPresupuestoImpl dpres = new DAOPresupuestoImpl();
    private final DAOEmpresaImpl daoEmpresa = new DAOEmpresaImpl();
    private final DAOClienteImpl daoCliente = new DAOClienteImpl();
    private NuevoPresupuestoDialogo presupuestoDialog;

    public PresupuestoForm() throws Exception {
        init();
        generarTabla();
        addEventListeners();
    }

    private void init() throws Exception {
        presupuestoDialog = new NuevoPresupuestoDialogo();
        clienteList.clear();
        empresaList.clear();
        presupuestos.clear();
        list.clear();
        clienteList = daoCliente.listarClientes();
        empresaList = daoEmpresa.listarEmpresas();
        presupuestos = dpres.listarPresupuestos();
        setClientes();
        setEmpresas();
        list = obtenerLista();
    }

    private void addEventListeners() {
        nuevoCli.addActionListener(e -> {
            NuevoClienteDialogo cliente = new NuevoClienteDialogo();
            Cliente cli = cliente.crearCliente();
            if (cli != null) {
                try {
                    daoCliente.insertar(cli);
                    init();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        nuevaEmp.addActionListener(e -> {
            NuevaEmpresaDialogo empresaDialogo = new NuevaEmpresaDialogo();
            Empresa emp = empresaDialogo.crearEmpresa();
            if (emp != null) {
                try {
                    daoEmpresa.insertar(emp);
                    init();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        insert.addActionListener(e -> {
            try {
                Presupuesto presupuesto = presupuestoDialog.crearPresupuesto();
                if (presupuesto != null) {
                    dpres.insertar(presupuesto);
                    actualizarTabla();
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        delete.addActionListener(e -> {
            try {
                eliminarFilas();
                actualizarTabla();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        update.addActionListener(e -> {
            Presupuesto pre;
            try {
                if (productosTabla.getSelectedRows().length == 0) {
                    JOptionPane.showMessageDialog(null, "No has seleccionado nada");
                    return;
                }

                if (productosTabla.getSelectedRows().length > 1) {
                    JOptionPane.showMessageDialog(null, "No puedes seleccionar más de un campo");
                    return;
                }
                pre = presupuestoDialog.actualizar(presupuestos.get(productosTabla.getSelectedRow()));
                if (pre != null) {
                    dpres.actualizar(pre);
                    actualizarTabla();
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        MainPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                try {
                    init();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
    }

    private void generarTabla() throws Exception {
        tableModel = new AbstractTableModel() {
            @Override
            public int getRowCount() {
                return list.size();
            }

            @Override
            public int getColumnCount() {
                return columnas.length;
            }

            @Override
            public String getColumnName(int column) {
                return columnas[column];
            }

            @Override
            public Object getValueAt(int rowIndex, int columnIndex) {
                return list.get(rowIndex).get(columnIndex);
            }
        };
        productosTabla.setModel(tableModel);
        panelTabla.add(new JScrollPane(productosTabla));
    }

    private List<List<Object>> obtenerLista() {
        for (Clases.Presupuesto presupuesto : presupuestos) {
            String producto = "";
            for (int i = 0; i < presupuesto.getProducto().size(); i++) {
                producto += presupuesto.getProducto().get(i).getNombre();
            }
            List<Object> l = new ArrayList<>();
            l.add(presupuesto.getId());
            l.add(presupuesto.getFecha());
            l.add(presupuesto.getCliente().getDNI());
            l.add(presupuesto.getCliente().getNombre());
            l.add(presupuesto.getTrabajador().getDNI());
            l.add(presupuesto.getTrabajador().getNombre());
            l.add(presupuesto.getEmpresa().getNombre());
            l.add(presupuesto.getEmpresa().getEstado());
            l.add(producto);
            l.add(presupuesto.getPrecioTotal());
            list.add(l);
        }
        return list;
    }


    private void eliminarFilas() throws Exception {
        if (productosTabla.getSelectedRows().length == 0) {
            JOptionPane.showMessageDialog(null, "No has seleccionado na");
            return;
        } try {
            for (int filaSeleccionada : productosTabla.getSelectedRows()) {
                dpres.eliminar(presupuestos.get(filaSeleccionada));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        actualizarTabla();
    }

    private void actualizarTabla() throws Exception {
        ((AbstractTableModel) tableModel).fireTableDataChanged();
        init();
    }

    private void setEmpresas() throws Exception {
        comboEmp.removeAllItems();
        for (Empresa emp : empresaList) {
            this.comboEmp.addItem(emp.getNombre());
        }
    }

    private void setClientes() throws Exception {
        comboCli.removeAllItems();
        for (Cliente cliente : clienteList) {
            this.comboCli.addItem(cliente.getNombre());
        }
    }

    public JPanel getMainPanel() {return MainPanel;}
}