package Formularios;

import Clases.Empresa;
import Clases.Producto;
import DAO.DAOEmpresaImpl;

import javax.swing.*;
import java.util.List;

public class NuevoProductoDialogo {
    private JTextField Nombre = new JTextField();
    private JTextField Stock = new JTextField();
    private JTextField Precio = new JTextField();
    private DAOEmpresaImpl daoEmpresa = new DAOEmpresaImpl();
    private JComboBox<String> comboEmpresa = new JComboBox<>();
    private List<Empresa> list = daoEmpresa.listarEmpresas();
    private final JComponent[] comps = new JComponent[]{
            new JLabel("Nombre: "), Nombre,
            new JLabel("Stock: "), Stock,
            new JLabel("Precio"), Precio,
            new JLabel("Empresa"), comboEmpresa
    };

    public NuevoProductoDialogo() throws Exception {
        setEmpresas();
    }

    public Producto crearProducto() throws Exception {
        int resultado = JOptionPane.showConfirmDialog(null, comps, "Añadir", JOptionPane.YES_NO_OPTION);
        Producto prod = new Producto();
        if (resultado == JOptionPane.YES_OPTION) {
            String comprobarNombre = Nombre.getText();
            String comprobarStock = Stock.getText();
            String comprobarPrecio = Precio.getText();
            if (comprobarNombre.isEmpty() || comprobarStock.isEmpty() || comprobarPrecio.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacios", "Error", JOptionPane.ERROR_MESSAGE);
                return crearProducto();
            }
            try {
                int stock = Integer.parseInt(comprobarStock);
                double precio = Double.parseDouble(comprobarPrecio);
                prod = new Producto(comprobarNombre, stock, precio);
                int selecionEmpresa = comboEmpresa.getSelectedIndex();
                prod.setEmpresa(list.get(selecionEmpresa));
                reiniciar();
                return prod;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Los campos de Stock y Precio no pueden contener letras", "Error", JOptionPane.WARNING_MESSAGE);
                return crearProducto();
            }
        }
        reiniciar();
        return null;
    }

    public Producto actualizar(Producto producto) throws Exception {
        Nombre.setText(producto.getNombre());
        Stock.setText(String.valueOf(producto.getStock()));
        Precio.setText(String.valueOf(producto.getPrecio()));
        int resultado = JOptionPane.showConfirmDialog(null, comps, "modificar", JOptionPane.YES_NO_OPTION);
        if (resultado == JOptionPane.NO_OPTION) {
            if (JOptionPane.showConfirmDialog(null, "Quieres salir?") == 0) {
                return null;
            }
            return actualizar(producto);
        }
        String comprobarNombre = Nombre.getText();
        String comprobarStock = Stock.getText();
        String comprobarPrecio = Precio.getText();
        if (comprobarNombre.isEmpty() || comprobarStock.isEmpty() || comprobarPrecio.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacios", "Error", JOptionPane.ERROR_MESSAGE);
            return actualizar(producto);
        }
        try {
            producto.setNombre(comprobarNombre);
            producto.setStock(Integer.parseInt(comprobarStock));
            producto.setPrecio(Double.parseDouble(comprobarPrecio));
            Empresa seleccionEmpresa = list.get(comboEmpresa.getSelectedIndex());
            producto.setEmpresa(seleccionEmpresa);
            reiniciar();
            return producto;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Los campos de Stock y Precio no pueden contener letras", "Error", JOptionPane.WARNING_MESSAGE);
            return actualizar(producto);
        }
    }

    private void reiniciar() {
        Nombre.setText("");
        Stock.setText("");
        Precio.setText("");
    }

    private void setEmpresas() throws Exception {
        list = daoEmpresa.listarEmpresas();
        for (Empresa emp : list) {
            this.comboEmpresa.addItem(emp.getNombre());
        }
    }
}