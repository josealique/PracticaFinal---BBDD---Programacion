package Formularios;

import Clases.Empresa;

import javax.swing.*;

public class NuevaEmpresaDialogo {
    private JTextField CIF;
    private JTextField Telefono;
    private JTextField Nombre;
    private JTextField Direccion;
    private JTextField Estado;

    public NuevaEmpresaDialogo() {
        CIF = new JTextField();
        Telefono = new JTextField();
        Nombre = new JTextField();
        Direccion = new JTextField();
        Estado = new JTextField();
    }

        public Empresa crearEmpresa () {
            JComponent[] comps = new JComponent[]{
                    new JLabel("CIF: "), CIF,
                    new JLabel("Telefono"), Telefono,
                    new JLabel("Nombre: "), Nombre,
                    new JLabel("Direccion: "), Direccion,
                    new JLabel("Estado :"), Estado
            };
            int resultado = JOptionPane.showConfirmDialog(null, comps, "Añadir Empresa", JOptionPane.YES_NO_CANCEL_OPTION);
            Empresa empresa = new Empresa();
            if (resultado == JOptionPane.YES_OPTION) {
                if (comprobarCamposVacios()) {
                    JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacios", "Error", JOptionPane.ERROR_MESSAGE);
                    return crearEmpresa();
                }
                try {
                    int cif = Integer.parseInt(CIF.getText());
                    int telefono = Integer.parseInt(Telefono.getText());
                    empresa = new Empresa(cif, telefono, Nombre.getText(), Direccion.getText(), Estado.getText());
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "El CIF y el Telefono no pueden contener letras", "Error", JOptionPane.ERROR_MESSAGE);
                    return crearEmpresa();
                }
                return empresa;
            }
            return null;
        }

    private boolean comprobarCamposVacios() {
        return CIF.getText().equals("") || Telefono.getText().equals("") || Nombre.getText().equals("") || Direccion.getText().equals("") || Estado.getText().equals("");
    }
}