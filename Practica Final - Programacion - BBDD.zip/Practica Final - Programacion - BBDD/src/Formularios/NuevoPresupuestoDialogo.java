package Formularios;

import Clases.*;
import DAO.*;

import javax.swing.*;
import java.util.*;

public class NuevoPresupuestoDialogo {
    private JTextField cantidad;
    private JComboBox<String> comboProducto;
    private JComboBox<String> comboCliente;
    private JComboBox<String> comboTrabajador;
    private JComboBox<String> comboEmpresa;
    private List<Cliente> clientes;
    private List<Trabajador> trabajadores;
    private List<Empresa> empresas;
    private List<Producto> productos;
    private List<Producto> seleccionados = new ArrayList<>();
    private DAOProducteImpl daoProducte = new DAOProducteImpl();
    private DAOClienteImpl daoCliente = new DAOClienteImpl();
    private DAOTrabajadorImpl daoTrabajador = new DAOTrabajadorImpl();
    private DAOEmpresaImpl daoEmpresa = new DAOEmpresaImpl();
    private JComponent[] comps;

    NuevoPresupuestoDialogo() throws Exception {
        productos = daoProducte.listarProductos();
        empresas = daoEmpresa.listarEmpresas();
        clientes = daoCliente.listarClientes();
        trabajadores = daoTrabajador.listarTrabajadores();
        cantidad = new JTextField();
        this.comboProducto = new JComboBox<>();
        this.comboCliente = new JComboBox<>();
        this.comboEmpresa = new JComboBox<>();
        this.comboTrabajador = new JComboBox<>();
        this.comps = new JComponent[]{
                new JLabel("cantidad: "), cantidad,
                new JLabel("Producto: "), comboProducto,
                new JLabel("Cliente"), comboCliente,
                new JLabel("Trabajador"), comboTrabajador,
                new JLabel("Empresa"), comboEmpresa
        };
        setProductos();
        setClientes();
        setEmpresas();
        setTrabajadores();
    }

    public Presupuesto crearPresupuesto() throws Exception {
        int resultado = JOptionPane.showConfirmDialog(null, comps, "Añadir", JOptionPane.YES_NO_OPTION);
        Presupuesto pre = new Presupuesto();
        if (resultado == JOptionPane.YES_OPTION) {
            String comprobarCantidad = cantidad.getText();
            if (comprobarCantidad.isEmpty()) {
                JOptionPane.showMessageDialog(null, "El campo de cantidad no puede estar vacio", "Warning", JOptionPane.WARNING_MESSAGE);
                return crearPresupuesto();
            }
            try {

                Producto seleccionProducto = productos.get(comboProducto.getSelectedIndex());
                if (!seleccionados.contains(seleccionProducto)) {
                    seleccionados.add(seleccionProducto);
                }

                pre.setProducto(seleccionados);
                pre.setPrecioTotal(getPrecioTotal(seleccionProducto));
                Cliente selecionCliente = clientes.get(comboCliente.getSelectedIndex());
                pre.setCliente(selecionCliente);

                Trabajador seleccionTrabajador = trabajadores.get(comboTrabajador.getSelectedIndex());
                pre.setTrabajador(seleccionTrabajador);

                Empresa seleccionEmpresa = empresas.get(comboEmpresa.getSelectedIndex());
                pre.setEmpresa(seleccionEmpresa);

                pre.setCantidad(Integer.parseInt(cantidad.getText()));
                reiniciar();
                return pre;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "El campo de cantidad no puede contener letras", "Warning", JOptionPane.WARNING_MESSAGE);
                return crearPresupuesto();
            }
        }
        reiniciar();
        return null;
    }

    public Presupuesto actualizar(Presupuesto pre) throws Exception {
        cantidad.setText(String.valueOf(pre.getCantidad()));
        int resultado = JOptionPane.showConfirmDialog(null, comps, "modificar", JOptionPane.YES_NO_OPTION);
        if (resultado == JOptionPane.NO_OPTION) {
            if (JOptionPane.showConfirmDialog(null, "Quieres salir?") == 0) {
                return null;
            }
            return actualizar(pre);
        }
        String comprobarCantidad = cantidad.getText();
        if (comprobarCantidad.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Los campos no pueden estar vacios", "Error", JOptionPane.ERROR_MESSAGE);
            return actualizar(pre);
        }
        try {
            Producto seleccionProducto = productos.get(comboProducto.getSelectedIndex());
            if (!seleccionados.contains(seleccionProducto)) {
                seleccionados.add(seleccionProducto);
            }
            pre.setProducto(seleccionados);
            pre.setPrecioTotal(getPrecioTotal(seleccionProducto));

            Cliente selecionCliente = clientes.get(comboCliente.getSelectedIndex());
            pre.setCliente(selecionCliente);

            Trabajador seleccionTrabajador = trabajadores.get(comboTrabajador.getSelectedIndex());
            pre.setTrabajador(seleccionTrabajador);

            pre.setCantidad(Integer.parseInt(comprobarCantidad));

            Empresa seleccionEmpresa = empresas.get(comboEmpresa.getSelectedIndex());
            pre.setEmpresa(seleccionEmpresa);
            reiniciar();
            return pre;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "El campo de cantidad no puede contener letras", "Warning", JOptionPane.WARNING_MESSAGE);
            return actualizar(pre);
        }
    }

    private void setEmpresas() throws Exception {
        empresas = daoEmpresa.listarEmpresas();
        for (Empresa emp : empresas) {
            this.comboEmpresa.addItem(emp.getNombre());
        }
    }

    private void setClientes() throws Exception {
        for (Cliente cli : clientes) {
            this.comboCliente.addItem(cli.getNombre());
        }
    }

    private void setTrabajadores() throws Exception {
        for (Trabajador trab : trabajadores) {
            this.comboTrabajador.addItem(trab.getNombre());
        }
    }

    private void setProductos() throws Exception {
        for (Producto prod : productos) {
            this.comboProducto.addItem(prod.getNombre());
        }
    }

    private void reiniciar() {cantidad.setText("");}

    private double getPrecioTotal(Producto producto) {
        return producto.getPrecio() * Integer.parseInt(cantidad.getText());
    }
}