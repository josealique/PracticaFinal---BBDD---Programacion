package Formularios;

import Clases.Cliente;
import javax.swing.*;

public class NuevoClienteDialogo {
    private JTextField DNI;
    private JTextField Nombre;
    private JTextField Apellidos;
    private JTextField Telefono;
    private JTextField Email;

    public NuevoClienteDialogo() {
        DNI = new JTextField();
        Nombre = new JTextField();
        Apellidos = new JTextField();
        Telefono = new JTextField();
        Email = new JTextField();
    }

    public Cliente crearCliente() {
        JComponent[] comps = new JComponent[]{
                new JLabel("DNI: "), DNI,
                new JLabel("Nombre: "), Nombre,
                new JLabel("Apellidos: "), Apellidos,
                new JLabel("Telefono"), Telefono,
                new JLabel("Email :"), Email
        };
        int resultado = JOptionPane.showConfirmDialog(null, comps, "Añadir Cliente", JOptionPane.YES_NO_CANCEL_OPTION);
        Cliente cliente = new Cliente();
        if (resultado == JOptionPane.YES_OPTION) {
            if (comprobarCamposVacios()){
                JOptionPane.showMessageDialog(null,"Los campos no pueden estar vacios","Error",JOptionPane.ERROR_MESSAGE);
                return crearCliente();
            } try {
                int telefono = Integer.parseInt(Telefono.getText());
                System.out.println("hola");
                cliente = new Cliente(DNI.getText(),Nombre.getText(),Apellidos.getText(),telefono,Email.getText());
            } catch (Exception e){
                JOptionPane.showMessageDialog(null,"El campo telefono no puede contener letras","Error",JOptionPane.ERROR_MESSAGE);
                return crearCliente();
            }
            return cliente;
        }
        return null;
    }

    private boolean comprobarCamposVacios(){
        return DNI.getText().equals("") || Nombre.getText().equals("") || Apellidos.getText().equals("") || Telefono.getText().equals("") || Email.getText().equals("");
    }
}