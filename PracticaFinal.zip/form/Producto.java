package form;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Producto {
    private JLabel Header;
    private JButton Insertar;
    private JTable table1;
    private JPanel MainPanel;
    private JButton Eliminar;
    private JButton modificarButton;

    public JPanel getMainPanel() {
        return MainPanel;
    }

    // Tabla
//    List<Producte> list = new ArrayList<>();
//    TableModel tableModel = new AbstractTableModel() {
//        @Override
//        public int getRowCount() {
//            return list.size();
//        }
//
//        @Override
//        public int getColumnCount() {
//            return 4;
//        }
//
//        @Override
//        public Object getValueAt(int rowIndex, int columnIndex) {
//            return null;
//        }
//
//        @Override
//        public String getColumnName(int column) {
//            switch (column){
//                case 0:
//                    return "Id Producto";
//                case 1:
//                    return "Nombre";
//                case 2:
//                    return "Precio_Base";
//                case 3:
//                    return "Stock";
//            }
//        }
//    }
}
