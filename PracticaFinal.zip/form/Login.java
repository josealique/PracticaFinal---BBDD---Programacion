package form;

import javax.swing.*;

public class Login {
    private JPanel MainPanel;
    private JTextField Usuario;
    private JPasswordField Password;
    private JButton entrarButton;


}